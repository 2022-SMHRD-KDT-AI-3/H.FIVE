var express  = require('express');
var router   = express.Router();
var multer   = require('multer');
const path = require("path");

const conn = require("../config/DB.js");


var storage  = multer.diskStorage({
  destination(req, file, cb) {
    cb(null, 'uploadedFiles/');
  },
  filename(req, file, cb) {
    const ext = path.extname(file.originalname);   // 파일 확장자

        // 새 파일명(기존파일명 + 확장자)

        const filename = path.basename(file.originalname, ext) + ext;

        cb(null, filename);

  },
});
var upload = multer({ dest: 'uploadedFiles/' });
var uploadWithOriginalFilename = multer({ storage: storage });

router.get('/campus/templet/D_main.html', function(req,res){
  res.render('upload');
});

router.post('/uploadFilesWithOriginalFilename', uploadWithOriginalFilename.array('attachments'), function(req,res){
  res.render('confirmation', { file:null, files:req.files });
});

/////////////////////////////////////////////////////
router.get("/search", function(request, response){

  let sql = "select * from camping";


  conn.query(sql,function(err, rows){

         response.render("search", {
           rows : rows
         })
  })

})

router.get("/choice", function(request, response){

  let place = request.param('local');
  let category = request.param('category');
  let who = request.param('who');

  console.log("선택한 지역"+place);
  console.log("선택한 유형"+category);
  console.log("선택한 사람"+who);
  

  let sql = "select * from camping where address like '%"+place+"%'and category like '%"+category+"%' and who like '%"+who+"%'"

  conn.query(sql,function(err, rows){

    // console.log("길이"+rows.length);
    // console.log(rows);

    //response.write(rows);
    response.json(rows);

    // response.render("search", {
    //   rows : rows
    // })

    // if(rows){

    // response.render("http://127.0.0.1:3000/search",{
    //   rows : rows
    // });

    // }else{
    //   console.log(err);
    // }

  })
})





router.get("/camp_info", function(request, response){

  let sql = "select * from camping,campImg";


  conn.query(sql,function(err, rows){

         response.render("camp_info", {
           rows : rows
         })
  })

})



module.exports = router;
