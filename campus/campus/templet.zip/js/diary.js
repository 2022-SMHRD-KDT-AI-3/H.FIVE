$(document).ready(function() {
	
  $("submit").click(function() {
    
    $("#container2").prepend("<div class='col-6 col-md-6 col-lg-3'></div>");

  });
});